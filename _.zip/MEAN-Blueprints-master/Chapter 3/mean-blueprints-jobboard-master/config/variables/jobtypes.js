"use strict";

module.exports = [
  {
    "name": "Full Time",
    "slug": "full-time"
  },
  {
    "name": "Part Time",
    "slug": "part-time"
  },
  {
    "name": "Project Based",
    "slug": "project-based"
  },
  {
    "name": "Apprenticeship",
    "slug": "apprenticeship"
  },
  {
    "name": "Summer Job",
    "slug": "summer-job"
  },
  {
    "name": "Limited term",
    "slug": "limited-term"
  },
  {
    "name": "Fixed term",
    "slug": "fixed-term"
  }
];
