'use strict';

module.exports = [
  {
    "name": "Accounting And Finance",
    "slug": "accounting-and-finance"
  },
  {
    "name": "Administrative Support",
    "slug": "administrative-support"
  },
  {
    "name": "Banking And Financial Services",
    "slug": "banking-and-financial-services"
  },
  {
    "name": "Business",
    "slug": "business"
  },
  {
    "name": "Childcare",
    "slug": "childcare"
  },
  {
    "name": "Community And Public Service",
    "slug": "community-and-public-service"
  },
  {
    "name": "Computers And Technology",
    "slug": "computers-and-technology"
  },
  {
    "name": "Construction",
    "slug": "construction"
  },
  {
    "name": "Customer Service",
    "slug": "customer-service"
  },
  {
    "name": "Education And Training",
    "slug": "education-and-training"
  },
  {
    "name": "Engineering",
    "slug": "engineering"
  },
  {
    "name": "Entertainment",
    "slug": "entertainment"
  },
  {
    "name": "Food And Beverage",
    "slug": "food-and-beverage"
  },
  {
    "name": "Healthcare",
    "slug": "healthcare"
  },
  {
    "name": "Hospitality",
    "slug": "hospitality"
  },
  {
    "name": "Human Resources",
    "slug": "human-resources"
  },
  {
    "name": "Installation And Maintenance",
    "slug": "installation-and-maintenance"
  },
  {
    "name": "Insurance",
    "slug": "insurance"
  },
  {
    "name": "Law Enforcement And Security",
    "slug": "law-enforcement-and-security"
  },
  {
    "name": "Legal",
    "slug": "legal"
  },
  {
    "name": "Management",
    "slug": "management"
  },
  {
    "name": "Manufacturing And Production",
    "slug": "manufacturing-and-production"
  },
  {
    "name": "Marketing",
    "slug": "marketing"
  },
  {
    "name": "Nursing",
    "slug": "nursing"
  },
  {
    "name": "Personal Services",
    "slug": "personal-services"
  },
  {
    "name": "Real Estate",
    "slug": "real-estate"
  },
  {
    "name": "Recreation",
    "slug": "recreation"
  },
  {
    "name": "Retail",
    "slug": "retail"
  },
  {
    "name": "Sales",
    "slug": "sales"
  },
  {
    "name": "Skilled Trades",
    "slug": "skilled-trades"
  },
  {
    "name": "Telecommunications",
    "slug": "telecommunications"
  },
  {
    "name": "Transportation And Distribution",
    "slug": "transportation-and-distribution"
  }
];
