import { Component } from 'angular2/core';

@Component({
  selector: 'chat-help',
  template: `
    <h2>Start a new conversation with someone</h2>
  `
})
export class ChatHelpComponent {
  constructor() {
  }
}
